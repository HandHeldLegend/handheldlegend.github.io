HOJA-EFM8UB1 version 1.17.2023.1

To flash, plug in your device while bridging pin C2D to ground to enter USB bootloader.
EFM8UB1 16kb devices all have the USB bootloader preinstalled :)
8kb models you are out of luck.

Depending on the controller there may be a shortcut.

With Open Controller, you can bridge the C2D pin to ground (located one pin over from the C2CK pin)
OR, the easier way, hold down the "EN" button on the ESP32 devkit while plugging in to USB type C.
This pin is conveniently routed to the C2D pin.

Finally, run the included .bat file