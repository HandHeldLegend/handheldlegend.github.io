@echo off
setlocal enabledelayedexpansion

:: HOJA wireless module (ESP32) updater for Windows.
:: Uses esptool (in this folder). Installs the HCI bridge firmware.
:: https://handheldlegend.github.io/hoja3/

set BRIDGE_BASE=https://raw.githubusercontent.com/HandHeldLegend/HOJA-ESP32-HCI-Bridge/main/build
set TMP_DIR=%~dp0firmware_temp

echo ===============================================
echo       HOJA wireless module (ESP32) updater
echo ===============================================
echo.

if not exist "%~dp0esptool.exe" (
    echo [ERROR] esptool.exe not found. Keep it in the same folder as this script.
    echo.
    pause
    exit /b 1
)

set NAME=HCI bridge
set BASE=%BRIDGE_BASE%
set APP_URL=%BRIDGE_BASE%/hoja_hci_bridge.bin
echo Installing: HCI bridge (needs current controller firmware: the app's Wireless page shows "ESP32 HCI")
echo.

if not exist "%TMP_DIR%" mkdir "%TMP_DIR%"

:: === DOWNLOAD ===
echo [1/3] Downloading bootloader...
curl -fL --progress-bar "!BASE!/bootloader/bootloader.bin" -o "%TMP_DIR%\bootloader.bin" || goto :DOWNLOAD_ERROR
echo [2/3] Downloading partition table...
curl -fL --progress-bar "!BASE!/partition_table/partition-table.bin" -o "%TMP_DIR%\partitions.bin" || goto :DOWNLOAD_ERROR
echo [3/3] Downloading firmware...
curl -fL --progress-bar "!APP_URL!" -o "%TMP_DIR%\firmware.bin" || goto :DOWNLOAD_ERROR
echo.
echo Download complete.
echo.

:: === UPDATE MODE ===
echo ===============================================
echo Put the controller in update mode
echo ===============================================
echo 1. Close browsers and other apps that might use the controller's COM port.
echo 2. Unplug the controller.
echo 3. Hold Start/Plus and R Bumper, keep holding, and plug it in.
echo    The lights pulse orange in update mode.
echo    (Or use the web app's wireless module update up to its Connect step, then close the browser.)
echo 4. Press any key to start.
echo.
pause

echo Erasing the module and writing !NAME! (takes about a minute)...
"%~dp0esptool.exe" --chip esp32 --baud 460800 --before default-reset --after hard-reset write-flash --erase-all ^
  0x1000 "%TMP_DIR%\bootloader.bin" ^
  0x8000 "%TMP_DIR%\partitions.bin" ^
  0x10000 "%TMP_DIR%\firmware.bin" || goto :FLASH_ERROR

echo.
echo ===============================================
echo [SUCCESS] !NAME! installed.
echo ===============================================
echo Unplug the controller to finish. Coming from the older HOJA baseband firmware?
echo Pair your Switch and other hosts again.
echo.
goto :CLEANUP

:DOWNLOAD_ERROR
echo.
echo [ERROR] Download failed. Check your internet connection and firewall, then try again.
echo.
goto :CLEANUP

:FLASH_ERROR
echo.
echo ===============================================
echo [ERROR] Couldn't talk to the wireless module
echo ===============================================
echo 1. Check the lights are pulsing orange. If not, unplug and enter update mode again.
echo 2. Use a USB data cable (not charge-only) and plug straight into the PC.
echo 3. Close any browser tab or app using the COM port, then run this again.
echo 4. If Windows doesn't show a COM port, install the CH340 driver (wch-ic.com, CH341SER).
echo.

:CLEANUP
if exist "%TMP_DIR%" rd /s /q "%TMP_DIR%" >nul 2>&1
echo.
pause
exit /b
